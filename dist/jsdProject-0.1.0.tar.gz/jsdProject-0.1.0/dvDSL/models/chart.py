class Chart:
  def __init__(self, chart_type, name):
    self.chart_type = chart_type
    self.name = name